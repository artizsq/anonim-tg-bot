# def check_code(command):
#     if len(command.text) > 6:
#         code = command.text[6:]


    
